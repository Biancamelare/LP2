﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;
using System.Xml.Linq;

namespace Pmatrizes
{
    public partial class Matrizes : Form
    {
        public Matrizes()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] Vetor = new int[20];
            string aux;
            for (var i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox("Digite o número", "Entrada de dados - Ler 20 números e inverter");
                if (!Int32.TryParse(aux, out Vetor[i]))
                {
                    MessageBox.Show("Dado inválido!","Erro");
                    i--;
                }
            }
            aux = "";
            for (var i = 19; i > 0; i--)
            {
                aux = aux + Vetor[i] + "\n";
            }
            MessageBox.Show(aux);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            double faturamento = 0;
            double[] qtd = new double[10];
            double[] vlr = new double[10];
            string auxiliar = "";
            for (var i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox("Digite a quantidade de mercadoria  " + (i + 1), "Entrada de Dados-Ler vetor quantidade");
                if (!Double.TryParse(auxiliar, out qtd[i]))
                {
                    MessageBox.Show("Quantidade inválida!");
                    i--;
                }
                else
                {
                    while (vlr[i] <= 0)
                    {
                        auxiliar = "";
                        auxiliar = Interaction.InputBox("Digite o valor da mercadoria  " + (i + 1), "Entrada de Dados-Ler vetor preço");
                        if (!Double.TryParse(auxiliar, out vlr[i]))
                        {
                            MessageBox.Show("Valor inválido!");
                        }
                    }
                }
                faturamento += qtd[i] + vlr[i];
            }
            MessageBox.Show("O faturamento é de: " + faturamento.ToString("N2"));
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
                MessageBox.Show("A varíavel total é de " + Total, "Exercício 3");
            }
            MessageBox.Show("Ao final do laço a varíavel total é de " + Total, "Exercício 3");
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList();
            string dados = "";
            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Débora");
            alunos.Add("Fátima");
            alunos.Add("João");
            alunos.Add("Janete");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");
            alunos.Remove("Otávio");
            foreach (string elemento in alunos)
            {
                dados += (elemento + "\n");
            }
            MessageBox.Show("Lista de alunos após exclusão do aluno Otávio: " + "\n" + dados);
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar;
            for (var i = 0; i < 20; i++)
            {
                for (var j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota " + (j + 1) + " do aluno " + (i + 1), "Média alunos");
                    if (!Double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }
                    else
                    {
                        if (!(notas[i, j] >= 0 && notas[i, j] <= 10))
                        {
                            MessageBox.Show("Nota inválida!");
                            j--;
                        }
                    }
                }
                double media = (notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3;
                MessageBox.Show("Aluno " + (i + 1) + ":Média " + media.ToString("N2"));
            }
        }

        private void btnEx6_Click(object sender, EventArgs e)
        {
            int ra = 2;
            string[] Vetor = new string[ra];
            int[] tamanho = new int[ra];
            string texto;

            for (var i = 0; i < ra; i++)
            {
                Vetor[i] = Interaction.InputBox((i + 1) + " Digite seu nome completo: ", "Entrada de dados - Ler nomes completos");
                tamanho[i] = Vetor[i].Trim().Length;
            }
            lbxNomes.Visible = true;
            lbxNomes.Items.Clear();
            for (var i = 0; i < ra; i++)
            {
                texto = "O nome: " + Vetor[i] + " tem " + tamanho[i] + " caracteres! " + "\n";
                lbxNomes.Items.Add(texto);
            }
        }

        private void lbxNomes_SelectedIndexChanged(object sender, EventArgs e)
        {
           lbxNomes.Visible = false;

            
        }
    }
}
