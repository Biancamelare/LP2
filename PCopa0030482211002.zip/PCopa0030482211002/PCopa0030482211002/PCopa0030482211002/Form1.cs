﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PCopa0030482211002
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
                 {

                 conexao = new SqlConnection("Data Source=APOLO;User ID=BD2211002; PASSWORD=Fatec@182203" );
                 conexao.Open();
                 }
                 catch (SqlException ex)
                 {
                 MessageBox.Show("Erro de banco de dados =/" + ex.Message);
                 }
                 catch (Exception ex)
                 {
                 MessageBox.Show("Outros Erros =/" + ex.Message);
                 }
                 }
                        }
}

