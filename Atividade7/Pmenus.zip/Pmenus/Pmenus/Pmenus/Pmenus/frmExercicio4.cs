﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumero_Click(object sender, EventArgs e)
        {
            string texto = rctxtTexto.Text.Trim();
            int comprimento = texto.Length;
            int total = 0;

            for(int i = 0; i < comprimento; i++)
            {
                if (Char.IsNumber(texto[i]))
                    total++;
            }
            MessageBox.Show("O total de números é: " + total.ToString());
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            string texto = rctxtTexto.Text;
            int comprimento = texto.Length;
            int i = 0;
            while(i<comprimento)
            {
                if (Char.IsWhiteSpace(texto[i]))
                    break;
                i++;
            }
            i = i + 1;
            MessageBox.Show("O primeiro espaço em branco está na posição: " + i.ToString());
        }

        private void btnAlfabetico_Click(object sender, EventArgs e)
        {
            string texto = rctxtTexto.Text.Trim();
            char[] arr = texto.ToCharArray();
            int total = 0;
            foreach ( var item in arr)
            {
                if (Char.IsLetter(item))
                    total++;
            }
            MessageBox.Show("O total de caracteres alfabéticos é: " + total.ToString());
        }
    }
}
