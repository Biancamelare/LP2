﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int num1=0, num2=0;

            if (int.TryParse(txtNum1.Text, out num1) &&
               int.TryParse(txtNum2.Text, out num2))
            {
                if ((num1 >= num2))
                {
                    MessageBox.Show("Número 2 deve ser maior que número 1!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtNum1.Focus();
                }
                else
                {
                    Random random = new Random();
                    double r = random.Next(num1, num2);
                    MessageBox.Show("O número sorteado é:" + r.ToString());
                }
            }
            else
            {
                MessageBox.Show("Valores inválidos!Digite somente números", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum1.Focus();
            }
        }

    }
}

