﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Psalario : Form
    {
        public Psalario()
        {
            InitializeComponent();
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            lblDados.Visible = true;
            double descontoINSS = 0;
            double descontoIRPF = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double numeroFilhos = 0;

            if (txtNome.Text == String.Empty)
            {
                MessageBox.Show("O nome do funcionário" + "\n não pode ser vazio!");
            }
            else
            {
                if (txtSalario.Text.Replace(",", "").Trim() == "")
                    MessageBox.Show("Não digitou salário.");

                if (!double.TryParse(txtSalario.Text, out salarioBruto) || !double.TryParse(nupdFilhos.Text, out numeroFilhos))
                {
                    MessageBox.Show("Salário bruto e número de filhos devem ser números!");
                }
                else
                {
                    if (salarioBruto <= 0)
                        MessageBox.Show("Salário Bruto deve ser maior que 0!");
                    else
                    {
                        if (salarioBruto <= 880.47)
                        {
                            mskbxINSS.Text = "7,65%";
                            descontoINSS = 0.0765 * salarioBruto;

                        }
                        else if (salarioBruto <= 1050)
                        {
                            mskbxINSS.Text = "8.65%";
                            descontoINSS = 0.0865 * salarioBruto;
                        }
                        else if (salarioBruto <= 1400.77)
                        {
                            mskbxINSS.Text = "9,00%";
                            descontoINSS = 0.09 * salarioBruto;
                        }
                        else if (salarioBruto <= 2801.56)
                        {
                            mskbxINSS.Text = "11,00%";
                            descontoINSS = 0.11 * salarioBruto;
                        }
                        else
                        {
                            mskbxINSS.Text = "Teto";
                            descontoINSS = 308.17;
                        }

                        mskbxDescontoINSS.Text = descontoINSS.ToString("N2");

                        if (salarioBruto <= 1257.12)
                            mskbxIRPF.Text = "0";
                        else if (salarioBruto <= 2512.08)
                        {
                            mskbxIRPF.Text = "15%";
                            descontoIRPF = (salarioBruto * 0.15);
                        }
                        else
                        {
                            mskbxIRPF.Text = "27,5%";
                            descontoIRPF = salarioBruto * 0.275;
                        }

                        mskbxDescontoIRPF.Text = descontoIRPF.ToString("N2");

                        if(numeroFilhos > 0)
                        {
                            if (salarioBruto <= 435.52)
                                salarioFamilia = 22.33 * numeroFilhos;
                            else if (salarioBruto <= 654.61)
                                salarioFamilia = 15.74 * numeroFilhos;
                            else
                                salarioFamilia = 0;
                        }

                        mskbxSalFamilia.Text = salarioFamilia.ToString("N2");

                        salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;

                        mskbxSalLiquido.Text = salarioLiquido.ToString("N2");

                        lblDados.Text = "Os descontos do salário  " +  (rbtnF.Checked ? "da Sra. " : "do Sr. ") +
                        txtNome.Text + " que é "     + (ckbxCasado.Checked ? "Casado(a) " : "Solteiro(a) ") + " e que tem  " + Convert.ToString(numeroFilhos) + "  filho(s) são: ";


                    }
                }
            }
        }
    }
}
