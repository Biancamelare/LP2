﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            lblDados.Visable = true; 
            double descontoINSS = 0;
            double descontoIRPF = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double numeroFilhos = 0;

            if(txtNome.Text == String.Empty)
            {
                MessageBox.Show("O nome do funcionário" + "\n não pode ser vazio!");
            }
            else
                if(!double.TryParse(mskbxSalario.Text, out salarioBruto) || !double.TryParse(nupdFilhos.TextAlign, out numeroFilhos))
                {
                    MessageBox.Show("Salário bruto e número de filhos devem ser números!");
                }
                else
                {
                    if (salarioBruto <= 0)
                        MessageBox.Show("Salário Bruto deve ser maior que 0");
                    else
                    {
                        if(salarioBruto <= 880.47)
                        {
                            mskbxINSS.Text = "7,65%";
                            descontoINSS = 0.0765 * salarioBruto;

                        }
                        else if(salarioBruto <= 1050)
                        {

                        }
                    }
                }
        }
    }
}
