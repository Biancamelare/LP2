﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalculadora
{
    public partial class Calculadora : Form
    {
       public Calculadora()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();

            txtNum1.Focus();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            double num1, num2, resultado;
        

            if ( Double.TryParse(txtNum1.Text, out num1) && 
               Double.TryParse(txtNum2.Text, out num2) )
           {
                resultado = num1 + num2;
                txtResultado.Text = resultado.ToString("N2");
           }
           else
           {
                MessageBox.Show("Erro:Uma ou ambas as entradas apresentam valores inválidos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum1.Focus();
           }
            /*try
                {
                    num1 = Convert.ToDouble(txtNum1.Text);
                    //num1 = Double.Parse(txtNum1.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Erro: Valores inválidos", "Erro...");

                }*/
        }

        private void Calculadora_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true; // desabilita o beep
                //Mudar: KeyPreview=True
            }
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            double num1, num2, resultado;


            if (Double.TryParse(txtNum1.Text, out num1) &&
               Double.TryParse(txtNum2.Text, out num2))
            {
                resultado = num1 - num2;
                txtResultado.Text = resultado.ToString("N2");
            }
            else
            {
                MessageBox.Show("Erro:Uma ou ambas as entradas apresentam valores inválidos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum1.Focus();
            }
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            double num1, num2, resultado;


            if (Double.TryParse(txtNum1.Text, out num1) &&
               Double.TryParse(txtNum2.Text, out num2))
            {
                if(num2 != 0)
                {
                    resultado = num1 / num2;
                    txtResultado.Text = resultado.ToString("N2");
                }
                else
                {
                    MessageBox.Show("Não é possível realizar divisão por 0", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Erro:Uma ou ambas as entradas apresentam valores inválidos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum1.Focus();
            }
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            double num1, num2, resultado;


            if (Double.TryParse(txtNum1.Text, out num1) &&
               Double.TryParse(txtNum2.Text, out num2))
            {
                resultado = num1 * num2;
                txtResultado.Text = resultado.ToString("N2");
            }
            else
            {
                MessageBox.Show("Erro:Uma ou ambas as entradas apresentam valores inválidos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum1.Focus();
            }
        }
    }
}
