﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PCopa0030482211002
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
                 {

                 conexao = new SqlConnection("Data Source=APOLO;User ID=BD2211002; PASSWORD=Fatec@182203" );
                 conexao.Open();
                 }
                 catch (SqlException ex)
                 {
                 MessageBox.Show("Erro de banco de dados =/" + ex.Message);
                 }
                 catch (Exception ex)
                 {
                 MessageBox.Show("Outros Erros =/" + ex.Message);
                 }
                 }

        private void cadastroJogosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmJogo"];
            if (fc != null)
                fc.Close();

            frmJogo objJ = new frmJogo();
            objJ.MdiParent = this;
            objJ.WindowState = FormWindowState.Maximized;
            objJ.Show();

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmSobre"];
            if (fc != null)
                fc.Close();

            frmSobre objJ = new frmSobre();
            objJ.MdiParent = this;
            objJ.WindowState = FormWindowState.Maximized;
            objJ.Show();
        }
       }
}

