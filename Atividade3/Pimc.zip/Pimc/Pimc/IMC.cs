﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class IMC : Form
    {
        public IMC()
        {
            InitializeComponent();
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            double peso, altura, imc;
            if(txtAltura.Text.Contains("."))
            { 
                txtAltura.Text = txtAltura.Text.Replace(".", ",");
            }
            if (txtPeso.Text.Contains("."))
            {
                txtPeso.Text = txtPeso.Text.Replace(".", ",");
            }

            if (Double.TryParse(txtAltura.Text, out altura) &&
                Double.TryParse(txtPeso.Text, out peso))
            {
                if ((altura <= 0) || (peso <= 0))
                {
                    MessageBox.Show("Valores devem ser maiores que zero!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPeso.Focus();
                }
                else
                {
                    imc = peso / (Math.Pow(altura, 2));

                    imc = Math.Round(imc, 1);
                    txtImc.Text = imc.ToString("N1");

                    if (imc < 18.5)
                        MessageBox.Show("Magreza", "Classificação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    else if (imc <= 24.9)
                        MessageBox.Show("Normal", "Classificação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else if (imc <= 29.9)
                        MessageBox.Show("Sobrepeso", "Classificação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else if (imc <= 39.9)
                        MessageBox.Show("Obesidade", "Classificação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    else
                        MessageBox.Show("Obesidade Grave", "Classificação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Valores inválidos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPeso.Focus();
            }
        }

        private void IMC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }
        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtImc.Clear();
            txtPeso.Clear();

            txtPeso.Focus();
        }
    }
}
