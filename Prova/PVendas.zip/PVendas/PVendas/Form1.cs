﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class Vendas : Form
    {
        public Vendas()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] Vendas = new double[2, 4];
            string auxiliar;
            double totalMes1=0;
            double totalMes2 = 0;
            double totalGeral = 0;
            string textoSemana;
            string textoMes;
            string textoTotal;
            for (var i = 0; i < 2; i++)
            {
                for (var j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a quantidade de vendas Mês:" + (i + 1) + " Semana " + (j + 1), "Entrada de Dados");
                    if (!Double.TryParse(auxiliar, out Vendas[i, j]))
                    {
                        MessageBox.Show("Valor inválido!");
                        j--;
                    }
                    else
                    {
                        if (Vendas[i, j] < 0)
                        {
                            MessageBox.Show("Valor inválido!");
                            j--;
                        }
                    }
                }
           }

            for (var i = 0; i < 1; i++)
            {
                for (var j = 0; j < 4; j++)
                {
                    totalMes1 += Vendas[i, j];
                }
            }
            for (var i = 1; i < 2; i++)
            {
                for (var j = 0; j < 4; j++)
                {
                    totalMes2 += Vendas[i, j];
                }
            }

            totalGeral = totalMes1 + totalMes2;

            for (var i = 0; i < 1; i++)
            {
                for (var j = 0; j < 4; j++)
                {
                    textoSemana = "Total do mês: " + (i+1) + " Semana: " + (j+1) + "  " + Vendas[i, j].ToString("N2") + "\n";
                    lbxVendas.Items.Add(textoSemana);
                }
                textoMes = "Total mês: " + totalMes1.ToString("N2") +"\n\n";
                lbxVendas.Items.Add(textoMes);
            }
            for (var i = 1; i < 2; i++)
            {
                for (var j = 0; j < 4; j++)
                {
                    textoSemana = "Total do mês: " + (i+1) + " Semana: " + (j+1) + "  " + Vendas[i, j].ToString("N2") + "\n\n";
                    lbxVendas.Items.Add(textoSemana);
                }
                textoMes = "Total mês: " + totalMes2.ToString("N2") + "\n\n";
                lbxVendas.Items.Add(textoMes);
            }
            textoTotal = "Total Geral: " + totalGeral.ToString("N2") + "\n\n";
            lbxVendas.Items.Add(textoTotal);
    }
    }
}
